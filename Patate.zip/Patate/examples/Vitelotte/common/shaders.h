extern const char* vert_points_glsl;
extern const char* geom_points_glsl;
extern const char* frag_points_glsl;
extern const char* vert_lines_glsl;
extern const char* geom_lines_glsl;
extern const char* frag_lines_glsl;
